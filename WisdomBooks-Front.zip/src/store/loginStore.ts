import { defineStore } from "pinia";


export const useAuthStore = defineStore("auth", {
  state: () => {
    return {
      isAuthenticated: false,
      token: "",
    };
  },
  getters: {
    getAuthenticated: (state) => state.isAuthenticated,
    getToken: (state) => state.token,
  },
  actions: {
    setAuth(isAuth: boolean) {
      this.isAuthenticated = isAuth;
    },
    setToken(token: string | null) {
      if (token) {
        this.token = token;
      } else {
        this.token = "";
      }
    },
  },
});
