import http from "./http";
import type { LoginFormInt } from "../types/loginType";
import {  bookTypeInt } from "../types/bookType";
import { readerRegister, readerType, readerTypeInt } from "../types/readerType";
import { newBorrow } from "../types/borrowType";


// 登录
export async function login(data: LoginFormInt) {
  return await http.get("/reader/login", data);
}

// 查询图书信息
export async function getBooks(data: any) {
  return await http.get("/book/page", data);
}

// 删除图书信息
export async function deleteBook(id: any) {
  return await http.delete("/book", id);
}

// 编辑图书信息
export async function updateBook(data: bookTypeInt) {
  return await http.put("/book", data);
}

// 新增图书信息
export async function addBookApi(data: bookTypeInt) {
  return await http.post("/book", data);
}

// 查询读者信息
export async function getReaders(data: any) {
  return await http.get("/reader/page", data);
}

// 删除读者信息
export async function deleteReader(id: any) {
  return await http.delete("/reader", id);
}
// 新增读者信息
export async function addReaderApi(data: readerType | readerRegister) {
  return await http.post("/reader", data);
}
// 编辑读者信息
export async function updateReaderApi(data: any) {
  return await http.put("/reader", data);
}
// 查询借书信息
export async function getBorrow(data: any) {
  return await http.get("/borrow/page", data);
}
// 新增借书记录
export async function addBorrowApi(data: newBorrow) {
  return await http.get("/borrow", data);
}
// 还书
export async function returnBorrowApi(data: newBorrow) {
  return await http.get("/borrow/backBook", data);
}
// 查询所有逾期
export async function getOverdueAll(data: any) {
  return await http.get("/rule/all", data);
}
// 根据借阅卡id查询逾期
export async function getOverdue(data: any) {
  return await http.get("/rule", data);
}

// 从借阅卡号查询读者信息
export async function getReaderToCardId(data: readerTypeInt) {
  return await http.get("/borrowCard", data);
}

// 查询性别比例
export async function getSexRatio() {
  return await http.get("/reader/sexCount");
}