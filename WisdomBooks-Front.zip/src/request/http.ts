import axios from "axios";

axios.defaults.baseURL = "http://localhost:8080/library";
axios.defaults.timeout = 20 * 1000;
axios.defaults.headers.put["Content-Type"] = "application/json";
axios.defaults.headers.post["Content-Type"] = "application/json";
// 添加请求拦截器
// axios.interceptors.request.use(
//   (config: AxiosRequestConfig | any) => {
//     config.headers = config.headers || {};
//     if (localStorage.getItem("token")) {
//       config.headers.token = localStorage.getItem("token") || "";
//     } else {
//       useRouter().push("/login");
//     }
//     return config;
//   },
//   function (error) {
//     return Promise.reject(error);
//   }
// );

// 添加响应拦截器
axios.interceptors.response.use(
  (response) => {
    return response;
  },
  function (error) {
    return Promise.reject(error);
  }
);
interface ResultInt {
  code: number; //编码：1成功，0和其它数字为失败
  msg: string; //错误信息
  data: any; //数据
  map: Map<string, any>; //动态数据
}

interface Http {
  get<T>(url: string, params?: unknown): Promise<ResultInt>;

  post<T>(url: string, params?: unknown): Promise<ResultInt>;

  upload<T>(url: string, params: unknown): Promise<ResultInt>;

  put<T>(url: string, params: unknown): Promise<ResultInt>;

  delete<T>(url: string, params: unknown): Promise<ResultInt>;

  download(url: string): void;
}

const http: Http = {
  get(url, params) {
    return new Promise((resolve, reject) => {
      axios
        .get(url, { params })
        .then((res) => {
          resolve(res.data);
        })
        .catch((err) => {
          console.log(err);
          reject(err.data);
        });
    });
  },

  post(url, params) {
    return new Promise((resolve, reject) => {
      axios
        .post(url, JSON.stringify(params))
        .then((res) => {
          resolve(res.data);
        })
        .catch((err) => {
          reject(err.data);
        });
    });
  },

  put(url, params) {
    return new Promise((resolve, reject) => {
      axios
        .put(url, JSON.stringify(params))
        .then((res) => {
          resolve(res.data);
        })
        .catch((err) => {
          reject(err.data);
        });
    });
  },

  delete(url, params) {
    return new Promise((resolve, reject) => {
      axios
        .delete(url, { params })
        .then((res) => {
          resolve(res.data);
        })
        .catch((err) => {
          reject(err.data);
        });
    });
  },

  upload(url, file) {
    return new Promise((resolve, reject) => {
      axios
        .post(url, file, {
          headers: { "Content-Type": "multipart/form-data" },
        })
        .then((res) => {
          resolve(res.data);
        })
        .catch((err) => {
          reject(err.data);
        });
    });
  },

  download(url) {
    const iframe = document.createElement("iframe");
    iframe.style.display = "none";
    iframe.src = url;
    iframe.onload = function () {
      document.body.removeChild(iframe);
    };

    document.body.appendChild(iframe);
  },
};

export default http;
