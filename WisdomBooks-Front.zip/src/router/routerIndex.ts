import { createRouter, createWebHistory, RouteRecordRaw } from "vue-router";
import { useAuthStore } from "../store/loginStore";


const routes: Array<RouteRecordRaw> = [
  {
    path: "/",
    name: "home",
    component: () => import("../views/HomeView.vue"),
    meta: {
      auth: true,
    },
    children: [
      {
        path: "total",
        name: "total",
        meta: {
          auth: true,
          isShow: true,
          title: "总 览",
        },
        component: () => import("../views/TotalView.vue"),
      },
      {
        path: "bookManagement",
        name: "bookManagement",
        meta: {
          auth: true,
          isShow: true,
          title: "图书信息管理",
        },
        component: () => import("../views/BookManagementView.vue"),
      },
      {
        path: "readerInfoManagement",
        name: "readerInfoManagement",
        meta: {
          auth: true,
          isShow: true,
          title: "读者信息管理",
        },
        component: () => import("../views/ReaderManagementView.vue"),
      },
      {
        path: "borrowingRules",
        name: "borrowingRules",
        meta: {
          auth: true,
          isShow: true,
          title: "逾期管理",
        },
        component: () => import("../views/OverdueInfoView.vue"),
      },
    ],
  },
  {
    path: "/login",
    name: "login",
    component: () => import("../views/LoginView.vue"),
    meta: {
      auth: false,
    },
  },
  {
    path: "/register",
    name: "register",
    component: () => import("../views/RegisterView.vue"),
    meta: {
      auth: false,
    },
  },
  {
    // 匹配失败跳转404页面
    path: "/:pathMatch(.*)*",
    component: () => import("../views/NotFoundView.vue"),
    meta: {
      auth: false,
    },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// 验证是否登录，自动跳转登录页面
router.beforeEach((to, from, next) => {
  const auth = useAuthStore().isAuthenticated;
  if (to.meta.auth) {
    if (!auth) {
      ElMessage({
        type: "error",
        message: "请先登录！！！",
        duration: 7000
      });
      next({ name: "login" });
    } else {
      next();
    }
  } else {
    next();
  }
});

export default router;
