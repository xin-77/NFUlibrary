<template>
  <div id="box">
    <!-- 新增弹窗 -->
    <el-dialog v-model="dialogFormVisible" title="新增读者信息" center>
      <el-form :model="nReaderData" :inline="true">
        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="nReaderData.name" autocomplete="off" />
        </el-form-item>
        <el-form-item label="性别" :label-width="formLabelWidth">
          <el-input v-model="nReaderData.sex" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取消</el-button>
          <el-button type="primary" @click="addReader"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 编辑弹窗 -->
    <el-dialog v-model="dialog2FormVisible" title="编辑读者信息" center>
      <el-form :model="nReaderData" :inline="true">
        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-input v-model="nReaderData.name" autocomplete="off" />
        </el-form-item>
        <el-form-item label="性别" :label-width="formLabelWidth">
          <el-input v-model="nReaderData.sex" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialog2FormVisible = false">取消</el-button>
          <el-button type="primary" @click="updateReader"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 借书弹窗  -->
    <el-dialog
      v-model="dialog3FormVisible"
      title="新增借书记录"
      center
      width="25%"
      align-center
    >
      <el-form :model="newBorrow" :inline="true">
        <el-form-item label="图书编号" :label-width="formLabelWidth">
          <el-input v-model="newBorrow.bookId" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialog3FormVisible = false">取消</el-button>
          <el-button type="primary" @click="addBorrow"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 还书弹窗  -->
    <el-dialog v-model="dialog4FormVisible" title="还书" center>
      <el-form :model="nReaderData" :inline="true">
        <el-form-item label="当前已借书本" :label-width="formLabelWidth">
          <el-tag
            v-for="book in nReaderData.borrowBooks"
            :key="book[0].id"
            size="large"
            @click="showBookId(book[0].id)"
          >
            <span>{{ book[0].bookName }}</span>
          </el-tag>
        </el-form-item>
        <el-divider />
        <el-form-item label="待还图书编号" :label-width="formLabelWidth">
          <el-input v-model="newbookId" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialog4FormVisible = false">取消</el-button>
          <el-button type="primary" @click="returnBorrow"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
    <div class="selectBox">
      <el-form
        :inline="true"
        :model="selectData"
        selectDatass="demo-form-inline"
      >
        <el-form-item label="检索条件" size="large">
          <el-select
            v-model="selectData.curOption"
            class="m-2"
            placeholder="姓名"
            size="large"
          >
            <el-option
              v-for="item in selectData.options"
              :key="item.id"
              :label="item.option"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item size="large">
          <el-input
            v-model="selectData.inputStr"
            placeholder="请输入搜索内容"
          />
        </el-form-item>
        <el-form-item size="large">
          <el-button type="primary" @click="selectBtn">查询</el-button>
        </el-form-item>
        <el-form-item size="large">
          <el-button type="primary" @click="addReaderBtn">新增读者</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 表格数据 -->
    <el-table :data="readers" border style="width: 100%" empty-text="无">
      <el-table-column
        type="index"
        :index="indexMethod"
        width="100px"
        label="ID"
        align="center"
      />
      <el-table-column
        prop="name"
        label="姓名"
        :resizable="false"
        width="200px"
        align="center"
      />
      <el-table-column
        prop="sex"
        label="性别"
        :resizable="false"
        width="100px"
        align="center"
      />
      <el-table-column
        prop="bookBorrows"
        :formatter="bookSplitData"
        label="借用书籍"
        :resizable="false"
        header-align="center"
        align="left"
      />

      <el-table-column
        prop="role"
        label="操作"
        :resizable="false"
        align="center"
        width="200px"
      >
        <template #default="scope">
          <el-button
            link
            size="small"
            type="primary"
            @click="addBorrowBtn(scope.row)"
          >
            借书
          </el-button>
          <el-button
            link
            size="small"
            type="primary"
            @click="returnBorrowBtn(scope.row)"
          >
            还书
          </el-button>
          <el-button
            link
            size="small"
            type="primary"
            @click="updateReaderBtn(scope.row)"
          >
            编辑读者
          </el-button>
          <el-button
            link
            size="small"
            type="primary"
            @click="deleteReaderBtn(scope.row)"
          >
            删除读者
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页条 -->
    <el-pagination
      @current-change="currentChange"
      @size-change="sizeChange"
      layout="prev, pager, next"
      :total="selectData.count"
      :page-size="selectData.pageSize"
    />
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref, toRefs, watch } from "vue";
import {
  getReaders,
  deleteReader,
  getBorrow,
  getBooks,
  addReaderApi,
  returnBorrowApi,
  addBorrowApi,
  updateReaderApi,
} from "../request/api";
import { newBorrow } from "../types/borrowType";
import { Reader, nReader } from "../types/readerType";

// 序号
const indexMethod = (index: number) => {
  return (selectData.value.page - 1) * selectData.value.pageSize + index + 1;
};
// 新的读者数据，用于弹窗和新增读者两个功能
const nReaderData = reactive(new nReader().data);
const newBorrow = ref<newBorrow>({
  bookId: undefined,
  borrowCardId: undefined,
});
const dialogFormVisible = ref(false);
const dialog2FormVisible = ref(false);
const dialog3FormVisible = ref(false);
const dialog4FormVisible = ref(false);
const formLabelWidth = "100px";
const data = reactive(new Reader());
const { readers, selectData } = toRefs(data);
// 动态参数用于发送请求
const parm = ref<string>("");
const parmP = ref<string | undefined>("");
watch(
  () => selectData.value,
  () => {
    parm.value =
      selectData.value.parameter.get(selectData.value.curOption) || "";
    parmP.value = selectData.value.inputStr;
  },
  { deep: true }
);

const getReaderData = () => {
  readers.value = [];
  getReaders({
    [parm.value]: parmP.value,
    page: selectData.value.page,
    pageSize: selectData.value.pageSize,
  }).then((res) => {
    // 查询所有读者
    for (const element of res.data.records) {
      // 查询每个读者id对应的借用表
      getBorrow({
        page: selectData.value.page,
        pageSize: selectData.value.pageSize,
        readerId: element.id,
      }).then(async (res) => {
        // 根据图书id查询图书名称
        let borrowBookList: any = [];
        for (let item of res.data.records) {
          await getBooks({
            page: 1,
            count: 0,
            pageSize: 10,
            inputStr: undefined,
            curOption: "",
            id: item.bookId,
          }).then((res) => {
            borrowBookList.push(res.data.records);
          });
        }
        readers.value.push({
          name: element.readerName,
          uid: element.id,
          auth: element.auth,
          sex: element.sex,
          borrowBooks: borrowBookList,
        });
      });
    }
    selectData.value.count = res.data.total;
  });
};
// 初始化读者信息
onMounted(() => {
  getReaderData();
});

// 查询指定读者数据
function selectBtn() {
  selectData.value.page = 1;
  getReaderData();
}
// 删除用户
const deleteReaderBtn = (row: any) => {
  deleteReader({ id: row.uid }).then((res) => {
    if (res.code == 1) {
      ElMessage.success("删除读者成功");
    } else {
      ElMessage.error("删除读者失败");
    }
    getReaderData();
  });
};

// 换页
const currentChange = (page: number) => {
  getReaderData();
  selectData.value.page = page;
};
// 新增读者
function addReaderBtn() {
  nReaderData.name = "";
  nReaderData.sex = "";
  nReaderData.borrowBooks = undefined;
  dialogFormVisible.value = true;
}
function addReader() {
  addReaderApi({
    readerName: nReaderData.name,
    password: "",
    auth: 2,
    sex: nReaderData.sex,
  }).then((res) => {
    if (res.code === 1) {
      ElMessage.success("添加读者成功");
      dialogFormVisible.value = false;
      getReaderData();
    } else {
      ElMessage.error("添加读者失败");
    }

  });
}
// 编辑读者
function updateReaderBtn(row: any) {
  nReaderData.uid = row.uid;
  nReaderData.name = row.name;
  nReaderData.sex = row.sex;
  nReaderData.auth = row.auth;
  dialog2FormVisible.value = true;
}

function updateReader() {
  updateReaderApi({
    id: nReaderData.uid,
    readerName: nReaderData.name,
    auth: nReaderData.auth,
    sex: nReaderData.sex,
  }).then((res) => {
    if (res.code === 1) {
      ElMessage.success("更改成功");
      dialog2FormVisible.value = false;
      getReaderData();
    } else {
      ElMessage.error("更改失败，请重试！");
    }
  });
}
// 借书
function addBorrowBtn(row: any) {
  console.log(row);

  nReaderData.uid = row.uid;
  dialog3FormVisible.value = true;
}
function addBorrow() {
  addBorrowApi({
    bookId: newBorrow.value.bookId,
    readerId: nReaderData.uid,
  }).then((res) => {
    if (res.code === 1) {
      ElMessage.success("借书成功");
      dialog3FormVisible.value = false;
      getReaderData();
    } else {
      ElMessage.error("借书失败，请重试！");
    }
  });
}

// 还书
const newbookId = ref<number>();
function returnBorrowBtn(row: any) {
  nReaderData.name = row.name;
  nReaderData.sex = row.sex;
  nReaderData.uid = row.uid;
  nReaderData.borrowBooks = row.borrowBooks;
  console.log(nReaderData.borrowBooks);

  dialog4FormVisible.value = true;
}
function returnBorrow() {
  returnBorrowApi({
    bookId: newbookId.value,
    readerId: nReaderData.uid,
  }).then((res) => {
    if (res.code === 1) {
      dialog4FormVisible.value = false;
      ElMessage.success("还书成功");
      getReaderData();
    } else {
      ElMessage.error("还书失败，请重试！");
    }
  });
}

function showBookId(bookId: any) {
  ElMessage("图书编号为：" + bookId);
}
const sizeChange = (pageSize: number) => {
  selectData.value.pageSize = pageSize;
};
const bookSplitData = (row: any) => {
  let arr: any = [];
  row.borrowBooks.forEach((item: any) => {
    for (const i of item) {
      arr.push("《" + i.bookName + "》");
    }
  });
  return arr.join(" ");
};
</script>

<style scoped lang="less">
#box {
  margin-top: 20px;
  margin-left: 20px;
  .selectBox {
    .el-form-item {
      margin: 0 5px 5px 0;
    }
  }
  .el-pagination {
    position: fixed;
    bottom: 27px;
    right: -55vw;
    width: 80%;
  }
  .el-tag {
    margin: 2px;
    cursor: pointer;
  }
}
</style>
