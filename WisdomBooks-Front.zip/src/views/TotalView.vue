<template>
  <el-row id="topBox">
    <el-col :span="11"><div id="sexChart"></div></el-col>
    <el-col :span="11"><div id="comehereChart"></div></el-col>
  </el-row>
  <el-row id="bottom">
    <el-col :span="24"><div id="borrowChart"></div></el-col>
  </el-row>
</template>

<script setup lang="ts">
import * as echarts from "echarts/core";
import {
  GridComponent,
  GridComponentOption,
  TitleComponent,
  TitleComponentOption,
  TooltipComponent,
  TooltipComponentOption,
} from "echarts/components";
import {
  LineChart,
  LineSeriesOption,
  PieChart,
  PieSeriesOption,
  BarChart,
  BarSeriesOption,
} from "echarts/charts";
import { LabelLayout, UniversalTransition } from "echarts/features";
import { CanvasRenderer } from "echarts/renderers";
import { getSexRatio } from "../request/api";
import { onMounted } from "vue";

echarts.use([
  TitleComponent,
  TooltipComponent,
  PieChart,
  CanvasRenderer,
  LabelLayout,
  LineChart,
  GridComponent,
  UniversalTransition,
  TooltipComponent,
  BarChart,
]);
type EChartsSexOption = echarts.ComposeOption<
  TitleComponentOption | TooltipComponentOption | PieSeriesOption
>;
type EChartsBorrowOption = echarts.ComposeOption<
  GridComponentOption | LineSeriesOption
>;
type EChartsComeHereOption = echarts.ComposeOption<
  | TooltipComponentOption
  | GridComponentOption
  | BarSeriesOption
  | LineSeriesOption
>;
var sexOption: EChartsSexOption;
var borrowOption: EChartsBorrowOption;
var ComehereOption: EChartsComeHereOption;

// 变量在mounted周期里面初始化
const sex: Map<string, string> = new Map();
let sexChart: echarts.ECharts;
let borrowChart: echarts.ECharts;
let comehereChart: echarts.ECharts;
onMounted(() => {
  // 性别比例图
  sexChart = echarts.init(document.getElementById("sexChart")!);
  sexChart.setOption(sexOption);
  // 借出折线图
  borrowChart = echarts.init(document.getElementById("borrowChart")!);
  borrowChart.setOption(borrowOption);
  // 进馆人数柱形图
  comehereChart = echarts.init(document.getElementById("comehereChart")!);
  comehereChart.setOption(ComehereOption);
});
// 性别比例图初始配置
sexOption = {
  title: {
    text: "读者性别比例",
    left: "center",
  },
  tooltip: {
    trigger: "item",
  },
  series: [
    {
      type: "pie",
      radius: "50%",
      color: ["#464646", "#FF9393"],
      data: [
        { value: 0, name: "男性 " },
        { value: 0, name: "女性 " },
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: "rgba(0, 0, 0, 0.5)",
        },
      },
    },
  ],
};
// 借阅变化图初始配置
borrowOption = {
  title: {
    text: "年度借阅量分布",
    left: "center",
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "shadow",
    },
  },
  xAxis: {
    type: "category",
    data: [
      "1月",
      "2月",
      "3月",
      "4月",
      "5月",
      "6月",
      "7月",
      "8月",
      "9月",
      "10月",
      "11月",
      "12月",
    ],
  },
  yAxis: {
    type: "value",
  },
  series: [
    {
      data: [150, 230, 224, 218, 135, 147, 260, 12, 643, 88, 235, 84],
      type: "line",
    },
  ],
};
// 进馆人数初始配置
ComehereOption = {
  title: {
    text: "一周进馆人数",
    left: "center",
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "shadow",
    },
  },
  toolbox: {
    feature: {
      dataView: { show: true, readOnly: false },
      magicType: { show: true, type: ["line", "bar"] },
      restore: { show: true },
      saveAsImage: { show: true },
    },
  },
  grid: {
    left: "3%",
    right: "4%",
    bottom: "3%",
    containLabel: true,
  },
  xAxis: [
    {
      type: "category",
      data: [
        "星期一",
        "星期二",
        "星期三",
        "星期四",
        "星期五",
        "星期六",
        "星期日",
      ],
      axisTick: {
        alignWithLabel: true,
      },
    },
  ],
  yAxis: [
    {
      type: "value",
    },
  ],
  series: [
    {
      name: "人数",
      type: "bar",
      barWidth: "60%",
      color: ["#5d5878"],
      data: [100, 52, 200, 334, 230, 330, 220],
    },
    {
      name: "人数",
      type: "line",
      color: ["#a3d183"],
      data: [100, 52, 200, 334, 230, 330, 220],
      tooltip: {
        show: false
      }
    },
  ],
};
getSexRatio().then((res) => {
  sex.set("男", res.data["男"]);
  sex.set("女", res.data["女"]);
  sexChart.showLoading();
  let count = Number(sex.get("男")) + Number(sex.get("女"));
  let manRatio = ((Number(sex.get("男")) / count) * 100).toFixed(2) + "%";
  let girlRatio = ((Number(sex.get("女")) / count) * 100).toFixed(2) + "%";
  // 后端获取数据后更新图表
  sexChart.setOption({
    series: [
      {
        data: [
          sex.get("男") !== "0"
            ? { value: Number(sex.get("男")), name: `男性 ${manRatio}` }
            : undefined,
          sex.get("女") !== "0"
            ? { value: Number(sex.get("女")), name: `女性 ${girlRatio}` }
            : undefined,
        ],
      },
    ],
  });
  sexChart.hideLoading();
});
</script>

<style scoped lang="less">
#topBox {
  margin-top: 20px;
  margin-left: 20px;
  #sexChart {
    width: calc(80vw / 2);
    height: 300px;
  }
  #comehereChart {
    width: calc(80vw / 2);
    height: 280px;
  }
  .el-col:first-child {
    // 右边框
    border-right: 1px solid #ccc;
    // 底边框
    &::after {
      /* 必须设置 content 属性才能生效 */
      content: "";
      /* border 宽度 */
      width: 85vw;
      /* border 高度 */
      height: 1px;
      background-color: #ccc;
      /* border 位置 absolute(绝对定位) */
      position: absolute;
      left: 0px;
      top: 100%;
      /* 自动内减 */
      box-sizing: border-box;
    }
  }
}
#bottom {
  margin-top: 20px;
  #borrowChart {
    width: 85vw;
    height: 400px;
  }
}
</style>
