<template>
  <div class="home">
    <el-container>
      <el-header>
        <el-row>

          <el-col :span="16"><h2>NFU智慧图书</h2></el-col>
          <el-col :span="2" :offset="2"
            ><el-button class="logout" round text @click="logout"
              >退出登录</el-button
            ></el-col
          >
        </el-row>
      </el-header>
      <el-container>
        <el-aside width="200px"
          ><el-menu
            active-text-color="#f6f6f6"
            background-color="#a4e5d9"
            class="el-menu-vertical-demo"
            default-active="2"
            text-color="#222831"
            router
          >
            <el-menu-item
              :index="item.path"
              v-for="item in list"
              :key="item.path"
            >
              <span>{{ item.meta.title }}</span>
            </el-menu-item>
          </el-menu></el-aside
        >
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script lang="ts" setup>
import { useRouter } from "vue-router";
import { useAuthStore } from "../store/loginStore";
const store = useAuthStore();
const router = useRouter();
const list = router.getRoutes().filter((v) => v.meta.isShow);
// 退出登录
const logout = () => {
  store.setAuth(false);
  store.setToken(null);
  localStorage.removeItem("token");
  router.push("/login");
};
</script>

<style lang="less" scoped>
.el-header {
  background-color: rgba(102, 199, 187,1);
  height: 80px;

  .logo {
    height: 60px;
    transform: translate(85%,15%);
  }

  h2,
  .logout {
    text-align: center;
    height: 80px;
    line-height: 80px;
    font-weight: 550;
    color: #22262b;
    font-family: tahoma, arial, Microsoft YaHei, Hiragino Sans GB,
      "\u5b8b\u4f53", sans-serif;
  }
  .logout:hover {
    background-color: rgba(#4ec3b5);
  }
}
.el-aside {
  .el-menu {
    background-color: #649dad;
    height: calc(100vh - 80px);
    .el-menu-item span {
      margin: 0 auto;
    }
  }
}

.el-main {
  padding: 0;
  height: calc(100vh - 90px);
}
</style>
