<template>
  <div id="building">
    <div class="login-box">
      <el-form
        ref="ruleFormRef"
        :model="ruleForm"
        status-icon
        :rules="rules"
        label-width="60px"
        hide-required-asterisk
        class="demo-ruleForm"
        v-loading="loading"
      >
        <h2>用户登录</h2>
        <el-form-item label="账号：" prop="username">
          <el-input
            v-model="ruleForm.username"
            autocomplete="off"
            placeholder="请输入账号"
          />
        </el-form-item>

        <el-form-item label="密码：" prop="password">
          <el-input
            v-model="ruleForm.password"
            type="password"
            autocomplete="off"
            placeholder="请输入密码"
          />
        </el-form-item>

        <el-form-item>
          <el-button
            class="loginBtn"
            type="primary"
            @click="submitForm(ruleFormRef)"
            >登录</el-button
          >

          <el-button class="loginBtn" @click="toRegister">去注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useAuthStore } from "../store/loginStore";
import { reactive, ref } from "vue";
import { useRouter } from "vue-router";
import { LoginData } from "../types/loginType";
import { FormInstance } from "element-plus";
import { login } from "../request/api";

const store = useAuthStore();
const router = useRouter();

const ruleForm = reactive(new LoginData()).ruleForm;
const rules = {
  username: [
    {
      required: true,
      message: "请输入账号",
      trigger: "blur",
    },
    {
      min: 3,
      max: 30,
      message: "账号的长度在3到30之间",
      trigger: "blur",
    },
  ],
  password: [
    {
      required: true,
      message: "请输入密码",
      trigger: "blur",
    },
    {
      min: 3,
      max: 10,
      message: "密码的长度在3到10之间",
      trigger: "blur",
    },
  ],
};
// 登录
const ruleFormRef = ref<FormInstance>();
const loading = ref(false);

// 注册
const toRegister = () => {
  router.push("/register");
};

const submitForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  formEl.validate((valid) => {
    if (valid) {
      loading.value = true;
      login(ruleForm).then((res) => {
        if (res.data === null || res.data.length == 0) {
          // 弹出提示：账号或密码错误
          // 爆红不用管，导入就丢样式了
          ElMessage({
            type: "error",
            message: "账号或密码错误，请重新输入",
          });
        } else {
          store.setAuth(true);
          store.setToken(res.data.id);
          localStorage.setItem("token", res.data.id);
          router.push("/total");
        }
        loading.value = false;
      });
    } else {
      return false;
    }
  });
};
</script>

<style lang="less" scoped>
#building {
  background: url("../assets/book_bg.png");
  width: 100%;
  height: 100vh;
  background-size: 100% 100%;
  .login-box {
    position: absolute;
    right: 5%;
    top: 20%;
    overflow: hidden;
    text-align: center;

    .demo-ruleForm {
      width: 400px;
      height: 250px;
      margin: 10px auto;
      background-color: #fff;
      padding: 40px;
      border-radius: 20px;
    }

    .loginBtn {
      width: 100vw;
      margin-top: 20px;
      &:last-child {
        margin: 20px 0;
      }
    }

    h2 {
      margin-bottom: 20px;
      color: #000;
    }
  }
}
</style>
