<template>
  <div class="_404">
    <h2>
      抱歉，页面未找到，<span>{{ countDown }}</span
      >s后自动跳转到
      <a href="javascript:;" @click="goHome">首页</a>
    </h2>
    <img src="../assets/404.jpeg" alt="页面未找到" />
  </div>
</template>

<script setup lang="ts">
import { onMounted, Ref, ref } from "vue";
import { useRouter } from "vue-router";

let timer: number | undefined;
onMounted(() => {
  timer = setInterval(() => {
    countDown.value > 0 ? countDown.value-- : goHome();
  }, 1000);
});
const router = useRouter();
let countDown: Ref<number> = ref(5);

const goHome = (): void => {
  router.push("/total");
  clearInterval(timer);
};
</script>

<style scoped lang="less">
._404 {
  width: 30%;
  margin: 10rem auto;
  img {
    transform: translateX(-10vw);
    width: 50rem;
    height: 40rem;
  }
  a {
    color: #010101;
    &:hover {
      color: skyblue;
    }
  }
}
</style>
