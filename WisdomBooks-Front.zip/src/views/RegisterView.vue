<template>
  <div id="building">
    <div class="register-box">
      <el-form
        ref="ruleFormRef"
        :model="ruleForm"
        status-icon
        :rules="rules"
        label-width="70px"
        hide-required-asterisk
        scroll-to-error
        class="demo-ruleForm"
      >
        <h2>用户注册</h2>
        <el-form-item label="用户名：" prop="username">
          <el-input
            v-model="ruleForm.username"
            autocomplete="off"
            placeholder="请输入用户名"
          />
        </el-form-item>

        <el-form-item label="密码：" prop="password">
          <el-input
            v-model="ruleForm.password"
            type="password"
            autocomplete="off"
            placeholder="请输入密码"
          />
        </el-form-item>
        <el-form-item label="性别：" prop="sex">
          <el-radio-group v-model="ruleForm.sex" class="ml-4">
            <el-radio label="男" size="large">男</el-radio>
            <el-radio label="女" size="large">女</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item>
          <el-button
            class="loginBtn"
            type="primary"
            @click="submitForm(ruleFormRef)"
            >注册</el-button
          >

          <el-button class="loginBtn" @click="toRegister">去登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from "vue";
import { useRouter } from "vue-router";
import { LoginData } from "../types/loginType";
import type { FormInstance } from "element-plus";
import { addReaderApi } from "../request/api";

const router = useRouter();

const ruleForm = reactive(new LoginData()).ruleForm;
const rules = {
  username: [
    {
      required: true,
      message: "请输入账号",
      trigger: "blur",
    },
    {
      min: 3,
      max: 10,
      message: "账号的长度在3到10之间",
      trigger: "blur",
    },
  ],
  password: [
    {
      required: true,
      message: "请输入密码",
      trigger: "blur",
    },
    {
      min: 3,
      max: 10,
      message: "密码的长度在3到10之间",
      trigger: "blur",
    },
  ],
  sex: [{ required: true, message: "请选择性别", trigger: "blur" }],
};
// 注册
const ruleFormRef = ref<FormInstance>();

// 跳转登录
const toRegister = () => {
  router.push("/login");
};

const submitForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  formEl.validate((valid) => {
    if (valid) {
      addReaderApi({
        readerName: ruleForm.username,
        password: ruleForm.password,
        auth: 1,
        sex: ruleForm.sex,
      }).then((res) => {
        // 注册成功即跳转
        if (res.code === 1) {
          router.push("/login");
        } else {
          // 爆红不用管，不用导入
          ElMessage({
            type: "error",
            message: "注册失败，请检查！",
          });
        }
      });
    } else {
      ElMessage({
        type: "error",
        message: "格式错误，请重新输入！",
      });
      return false;
    }
  });
};
</script>

<style lang="less" scoped>
#building {
  background: url("../assets/book_bg.png");
  width: 100%;
  height: 100vh;
  background-size: 100% 100%;
  .register-box {
    position: absolute;
    right: 5%;
    top: 20%;
    overflow: hidden;
    text-align: center;
    .demo-ruleForm {
      width: 400px;
      height: 300px;
      margin: 10px auto;
      background-color: #fff;
      padding: 40px;
      border-radius: 20px;
    }
    .loginBtn {
      width: 100vw;
      margin-top: 20px;
      &:last-child {
        margin: 20px 0;
      }
    }
    h2 {
      margin-bottom: 20px;
      color: #000;
    }
  }
}
</style>
