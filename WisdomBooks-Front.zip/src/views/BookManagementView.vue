<template>
  <div id="box">
    <!-- 新增弹窗 -->
    <el-dialog v-model="dialogFormVisible" title="新增图书信息" center>
      <el-form :model="nBook" :inline="true">
        <el-form-item label="图书名" :label-width="formLabelWidth">
          <el-input v-model="nBook.bookName" autocomplete="off" />
        </el-form-item>
        <el-form-item label="作者" :label-width="formLabelWidth">
          <el-input v-model="nBook.author" autocomplete="off" />
        </el-form-item>
        <el-form-item label="库存" :label-width="formLabelWidth">
          <el-input v-model="nBook.stock" autocomplete="off" />
        </el-form-item>
        <el-form-item label="出版社" :label-width="formLabelWidth">
          <el-input v-model="nBook.publish" autocomplete="off" />
        </el-form-item>
        <el-form-item label="价格" :label-width="formLabelWidth">
          <el-input v-model="nBook.price" autocomplete="off" />
        </el-form-item>
        <el-form-item label="出版日期" :label-width="formLabelWidth">
          <el-popover
            ref="popover"
            placement="right"
            title="Title"
            :width="200"
            trigger="focus"
            content="日期"
          >
            <template #reference>
              <el-date-picker
                v-model="nBook.publishDate"
                type="date"
                placeholder="请选择出版日期"
                value-format="YYYY-MM-DD"
                size="default"
              />
            </template>
          </el-popover>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取消</el-button>
          <el-button type="primary" @click="addBook"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
    <!-- 编辑弹窗 -->
    <el-dialog v-model="dialog2FormVisible" title="编辑图书信息" center>
      <el-form :model="nBook" :inline="true">
        <el-form-item label="图书名" :label-width="formLabelWidth">
          <el-input v-model="nBook.bookName" autocomplete="off" />
        </el-form-item>
        <el-form-item label="作者" :label-width="formLabelWidth">
          <el-input v-model="nBook.author" autocomplete="off" />
        </el-form-item>
        <el-form-item label="库存" :label-width="formLabelWidth">
          <el-input v-model="nBook.stock" autocomplete="off" />
        </el-form-item>
        <el-form-item label="出版社" :label-width="formLabelWidth">
          <el-input v-model="nBook.publish" autocomplete="off" />
        </el-form-item>
        <el-form-item label="价格" :label-width="formLabelWidth">
          <el-input v-model="nBook.price" autocomplete="off" />
        </el-form-item>
        <el-form-item label="出版日期" :label-width="formLabelWidth">
          <el-popover
            ref="popover"
            placement="right"
            title="Title"
            :width="200"
            trigger="focus"
            content="日期"
          >
            <template #reference>
              <el-date-picker
                v-model="nBook.publishDate"
                type="date"
                placeholder="请选择出版日期"
                value-format="YYYY-MM-DD"
                size="default"
              />
            </template>
          </el-popover>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialog2FormVisible = false">取消</el-button>
          <el-button type="primary" @click="changeBook"> 确认 </el-button>
        </span>
      </template>
    </el-dialog>
    <div class="selectBox">
      <el-form
        :inline="true"
        :model="selectData"
        selectDatass="demo-form-inline"
      >
        <el-form-item label="检索条件" size="large">
          <el-select
            v-model="selectData.curOption"
            class="m-2"
            placeholder="全部"
            size="large"
          >
            <el-option
              v-for="item in selectData.options"
              :key="item.id"
              :label="item.option"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item size="large">
          <el-input
            v-model="selectData.inputStr"
            placeholder="请输入搜索内容"
          />
        </el-form-item>
        <el-form-item size="large">
          <el-button type="primary" @click="selectBtn">查询</el-button>
        </el-form-item>
        <el-form-item size="large">
          <el-button type="primary" @click="addBookBtn">新增图书</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 表格数据 -->
    <el-table :data="bookList" border style="width: 100%" empty-text="无">
      <el-table-column prop="id" label="图书编号" align="center"/>
      <el-table-column
        prop="bookName"
        label="图书名"
        :resizable="false"
        align="center"
      />
      <el-table-column
        prop="author"
        label="作者名"
        :resizable="false"
        align="center"
      />
      <el-table-column
        prop="stock"
        label="库存"
        width="180"
        :resizable="false"
        align="center"
      />

      <el-table-column
        prop="publish"
        label="出版社"
        :resizable="false"
        align="center"
      />
      <el-table-column
        prop="publishDate"
        label="印刷时间"
        :resizable="false"
        align="center"
      />
      <el-table-column
        prop="price"
        label="价格(¥)"
        :resizable="false"
        align="center"
      />
      <el-table-column
        prop="role"
        label="操作"
        :resizable="false"
        align="center"
      >
        <template #default="scope">
          <el-button
            link
            size="small"
            type="primary"
            @click="changeBookBtn(scope.row)"
          >
            编辑
          </el-button>
          <el-button
            link
            size="small"
            type="primary"
            @click="deleteBookBtn(scope.row)"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页条 -->
    <el-pagination
      @current-change="currentChange"
      @size-change="sizeChange"
      layout="prev, pager, next"
      :total="selectData.count"
      :page-size="selectData.pageSize"
    />
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref, toRefs, watch, watchEffect } from "vue";
import { addBookApi, deleteBook, getBooks, updateBook } from "../request/api";
import { bookAllData, bookTypeInt, bookData } from "../types/bookType";

// 序号
const indexMethod = (index: number) => {
  return (selectData.value.page - 1) * selectData.value.pageSize + index + 1;
};
// 新的图书数据，用于弹窗和新增图书两个功能
const nBook = reactive(new bookData().book);
const dialogFormVisible = ref(false);
const dialog2FormVisible = ref(false);
const formLabelWidth = "100px";
const data = reactive(new bookAllData());
const { bookList, selectData } = toRefs(data);
// 动态参数用于发送请求
const parm = ref<string>("");
const parmP = ref<string | undefined>("");
watch(
  () => selectData.value,
  () => {
    parm.value =
      selectData.value.parameter.get(selectData.value.curOption) || "0";
    parmP.value = selectData.value.inputStr;
  },
  { deep: true }
);

const getBookData = () => {
  getBooks({
    [parm.value]: parmP.value,
    page: selectData.value.page,
    pageSize: selectData.value.pageSize,
  }).then((res) => {
    bookList.value = res.data.records;
    selectData.value.count = res.data.total;
    console.log(bookList.value);
  });
};
// 初始化图书信息
onMounted(() => {
  getBookData();
});

// 查询指定图书数据
function selectBtn() {
  selectData.value.page = 1;
  getBookData();
}
// 删除图书
const deleteBookBtn = (row: bookTypeInt) => {
  deleteBook({ id: row.id }).then((res) => {
    if (res.code == 1) {
      ElMessage.success("删除图书成功");
    } else {
      alert("删除图书失败");
      // 弹出提示：账号或密码错误
      // 爆红不用管，导入就丢样式了
      ElMessage.errror("删除图书失败，请重试");
    }
    getBookData();
  });
};
function changeBookBtn(row: bookTypeInt) {
  nBook.author = row.author;
  nBook.bookName = row.bookName;
  nBook.id = row.id;
  nBook.stock = row.stock;
  nBook.residue = row.residue || row.stock;
  nBook.price = row.price;
  nBook.publish = row.publish;
  nBook.publishDate = row.publishDate;
  dialog2FormVisible.value = true;
}
// 编辑图书信息
const changeBook = (row: bookTypeInt) => {
  updateBook(nBook).then((res) => {
    dialog2FormVisible.value = false;
    // 更新表格UI
    getBookData();
  });
};
// 换页
const currentChange = (page: number) => {
  selectData.value.page = page;
  getBookData();
};
// 新增图书
const addBookBtn = () => {
  nBook.author = "";
  nBook.bookName = "";
  nBook.stock = undefined;
  nBook.price = undefined;
  nBook.publish = "";
  nBook.publishDate = "";
  dialogFormVisible.value = true;
};
const addBook = () => {
  dialogFormVisible.value = false;
  addBookApi(nBook).then((res) => {
    getBookData();
  });
};
const sizeChange = (pageSize: number) => {
  selectData.value.pageSize = pageSize;
};
</script>

<style scoped lang="less">
#box {
  margin-top: 20px;
  margin-left: 20px;
  .selectBox {
    .el-form-item {
      margin: 0 5px 5px 0;
    }
  }
  .el-pagination {
    position: fixed;
    bottom: 27px;
    right: -55vw;
    width: 80%;
  }
}
</style>
