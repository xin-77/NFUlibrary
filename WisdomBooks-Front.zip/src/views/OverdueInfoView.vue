<template>
  <div id="box">
    <div class="selectBox">
      <el-form
        :inline="true"
        :model="selectData"
        selectDatass="demo-form-inline"
      >
        <el-form-item label="检索条件" size="large">
          <el-select
            v-model="selectData.curOption"
            class="m-2"
            placeholder="全部"
            size="large"
          >
            <el-option
              v-for="item in selectData.options"
              :key="item.id"
              :label="item.option"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item size="large">
          <el-input
            v-model="selectData.inputStr"
            placeholder="请输入搜索内容"
          />
        </el-form-item>
        <el-form-item size="large">
          <el-button type="primary" @click="selectBtn">查询</el-button>
        </el-form-item>

      </el-form>
    </div>
    <!-- 表格数据 -->
    <el-table
      :data="overdueData"
      border
      style="width: 100%"
      empty-text="无"
    >
      <el-table-column type="index" :index="indexMethod" label="ID" />
      <el-table-column
        prop="readerName"
        label="姓名"
        :resizable="false"
        align="center"
      />
      <el-table-column
        prop="overdueNum"
        label="逾期本数"
        :resizable="false"
        align="center"
      />
      <el-table-column
        prop="overdueFine"
        label="待缴纳罚款"
        :resizable="false"
        align="center"
      />
    </el-table>
    <!-- 分页条 -->
    <el-pagination
      @current-change="currentChange"
      @size-change="sizeChange"
      layout="prev, pager, next"
      :total="selectData.count"
      :page-size="selectData.pageSize"
    />
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref, toRefs, watch } from "vue";
import { getOverdue, getOverdueAll, getReaderToCardId } from "../request/api";
import { OverdueC } from "../types/overdueType";

// 序号
const indexMethod = (index: number) => {
   return (selectData.value.page-1) * selectData.value.pageSize + index + 1;
};

const dialogFormVisible = ref(false);
const dialog2FormVisible = ref(false);
const data = reactive(new OverdueC());
const { overdueData, selectData } = toRefs(data);
// 动态参数用于发送请求
const parm = ref<string>("");
const parmP = ref<string | undefined>("");
watch(
  () => selectData.value,
  () => {
    parm.value =
      selectData.value.parameter.get(selectData.value.curOption) || "";
    parmP.value = selectData.value.inputStr;
  },
  { deep: true }
);

const getPageAllData = () => {
  // 查询所有逾期借阅证
  getOverdueAll({
    borrowCardId: undefined,
    page: 1,
    pageSize: 10,
  }).then((res) => {
    // 根据借阅关系查询读者名和书名和各读者逾期书本总量
    overdueData.value = [];
    for (const item of res.data.records) {
      getReaderToCardId({
        inputStr: undefined,
        curOption: "",
        page: 0,
        count: 0,
        pageSize: 0,
        cardId: item.borrowCardId,
      }).then((res) => {
        overdueData.value.push({
          readerName: res.data.readerName,
          borrowCardId: item.borrowCardId,
          bookList: [],
          overdueNum: item.overdueNum,
          overdueFine: item.overdueFine,
        });
      });
    }
  });
};
const getPageData = () => {
  // 查询所有逾期借阅证
  getOverdue({
    [parm.value]: parmP.value,
    page: 1,
    pageSize: 10,
  }).then((res) => {
    overdueData.value = [];
    // 根据借阅关系查询读者名和书名和各读者逾期书本总量
    for (const item of res.data.records) {
      getReaderToCardId({
        inputStr: undefined,
        curOption: "",
        page: 0,
        count: 0,
        pageSize: 0,
        cardId: item.borrowCardId,
      }).then((res) => {
        overdueData.value.push({
          readerName: res.data.readerName,
          borrowCardId: item.borrowCardId,
          bookList: [],
          overdueNum: item.overdueNum,
          overdueFine: item.overdueFine,
        });
      });
    }
  });
};
// 初始化信息
onMounted(() => {
  getPageAllData();
});

// 查询指定数据
function selectBtn() {
  selectData.value.page = 1;
  getPageData();
}
// 删除

// 换页
const currentChange = (page: number) => {
  selectData.value.page = page;
  getPageData();
};

const sizeChange = (pageSize: number) => {
  selectData.value.pageSize = pageSize;
};
</script>

<style scoped lang="less">
#box {
  margin-top: 20px;
  margin-left: 20px;
  .selectBox {
    .el-form-item {
      margin: 0 5px 5px 0;
    }
  }
  .el-pagination {
    position: fixed;
    bottom: 27px;
    right: -55vw;
    width: 80%;
  }
}
</style>
