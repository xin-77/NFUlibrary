<script setup lang="ts">
import { watchEffect } from "vue"; //watchEffect一进来就触发
import { useAuthStore } from "./store/loginStore";
import zhCn from 'element-plus/lib/locale/lang/zh-cn'

// pinia仓库
const store = useAuthStore();
// 语言为中文
const locale = zhCn
// 页面刷新，pinia中存储的状态依然存在
watchEffect(() => {
  //watchEffect页面一刷新，方法立即被调用
  if (localStorage.token) {
    const decode = localStorage.getItem("token");
    store.setAuth(!!decode);
  }
});
</script>

<template>
  <el-config-provider :locale="locale">
  		<router-view />
	</el-config-provider>
</template>

<style scoped lang="less">
</style>
