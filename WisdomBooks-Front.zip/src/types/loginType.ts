export interface LoginFormInt {
  username: string;
  password: string;
  sex?: string;
}

export class LoginData {
  ruleForm: LoginFormInt = {
    username: "",
    password: "",
  };
}
