export interface inputDataInt {
  inputStr: string | undefined; //搜索文本
  curOption: string; // 当前选项
}
export interface pagingInt {
  page: number; // 当前页
  count: number; // 记录总数
  pageSize: number; // 页数
}
interface optionInt {
  id: string;
  option: string;
}
export interface optionInts {
  options: optionInt[];
  // 根据所选项id不同，发送不同的参数，例如：<0, id>、<1, bookName>
  parameter: Map<string, string>;
}
export type selectInputDataType = pagingInt & inputDataInt;
