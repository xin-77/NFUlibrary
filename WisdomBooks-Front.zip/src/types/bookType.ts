import { optionInts, selectInputDataType } from "./selectType";

export interface bookTypeInt {
  id: number | undefined;
  stock: number | undefined;
  residue: number | undefined;
  bookName: string;
  author: string;
  publish: string;
  publishDate: string;
  price: number | undefined;
}
interface book {
  id?: number;
}
export type bookSelect = book & selectInputDataType;
export class bookAllData {
  bookList: bookTypeInt[] = [];
  selectData: selectInputDataType & optionInts = {
    inputStr: undefined,
    curOption: '',
    page: 1,
    count: 0,
    pageSize: 15,
    parameter: new Map([
      ['0', "all"],
      ['1', "author"],
      ['2', "bookName"],
      ['3', "publish"],
    ]),
    options: [
      {
        id: '0',
        option: "全部",
      },
      {
        id: '1',
        option: "作者",
      },
      {
        id: '2',
        option: "书名",
      },
      {
        id: '3',
        option: "出版社",
      },
    ],
  };
}

export class bookData {
  book: bookTypeInt = {
    id: undefined,
    stock: undefined,
    residue: undefined,
    bookName: "",
    author: "",
    publish: "",
    publishDate: "",
    price: undefined,
  };
}
