export interface ResultInt {
  code: number; //编码：1成功，0和其它数字为失败
  msg: string; //错误信息
  data: [] | string | number; //数据
  map: Map<string, any>; //动态数据
}

