export interface userType {
  account: number,
  name: string
}

export interface FormInstance {
  
}