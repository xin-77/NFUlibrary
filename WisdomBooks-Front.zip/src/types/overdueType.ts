import { selectInputDataType, optionInts } from "./selectType";

export interface overdueInt {
  borrowCardId: number; // 借阅证id
  bookList: overdueeInt[];
  overdueNum: number;
  overdueFine: number;
  readerName:string;
}
export interface overdueeInt {
  bookId: number; // 图书id
  borrowCardId: number; // 借阅证id
  overdueDays: number; // 超期天数
  overdueFine: number; // 罚款
}
export interface overdueSelect {
  borrowCardId: number | undefined; // 借阅证id
  page: number; // 当前页
  pageSize: number; // 页数
}
export class OverdueC {
  overdueData: overdueInt[] = [];
  selectData: selectInputDataType & optionInts = {
    inputStr: undefined,
    curOption: "0",
    page: 1,
    count: 0,
    pageSize: 13,
    options: [
      {
        id: "0",
        option: "姓名",
      },
    ],
    parameter: new Map([["0", "username"]]),
  };
}
