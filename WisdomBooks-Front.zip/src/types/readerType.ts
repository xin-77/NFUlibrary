import { bookTypeInt } from "./bookType";
import { optionInts, selectInputDataType } from "./selectType";

export type readerType = {
  uid: number | undefined;
  name: string; // 读者名字
  auth: number; // 权限
  sex: string; // 性别
  borrowBooks: bookBorrow; // 读者当前借了还没还的书
  cardId?: number;
};

export type readerRegister = {
  readerName: string; // 读者名字
  password: string;
  auth: number; // 权限
  sex: string | undefined; // 性别
};

type bookAndBorrow = {
  borrowDate: string; // 借书时间
  returnDate: string; // 还书时间
  isRenew: number; // 是否续借
};

export interface readerTypeInt {
  inputStr: string | undefined; //搜索文本
  curOption: string; // 当前选项
  page: number;
  count: number;
  pageSize: number;
  id?: number;
  cardId?: number;
}
export type bookBorrow = (bookTypeInt & bookAndBorrow) | undefined;

export class nReader {
  data: readerType = {
    uid: undefined,
    name: "",
    auth: 0,
    sex: "",
    borrowBooks: undefined,
  };
}

export class ReaderData {
  data: readerType = {
    uid: undefined,
    name: "",
    sex: "",
    auth: 2,
    borrowBooks: {
      id: undefined,
      stock: undefined,
      residue: undefined,
      bookName: "",
      author: "",
      publish: "",
      publishDate: "",
      price: undefined,
      borrowDate: "",
      returnDate: "",
      isRenew: 0,
    },
  };
  constructor(
    public name: string,
    public uid: number,
    public auth: number,
    public borrowBooks: bookBorrow
  ) {
    this.data.name = name;
    this.data.uid = uid;
    this.data.auth = auth;
    this.data.borrowBooks = borrowBooks;
  }
}

export class Reader {
  readers: readerType[] = [];
  selectData: selectInputDataType & optionInts = {
    inputStr: undefined,
    curOption: "0",
    page: 1,
    count: 0,
    pageSize: 9,
    options: [
      {
        id: "0",
        option: "姓名",
      },
    ],
    parameter: new Map([["0", "username"]]),
  };
}
