export interface borrowTnt {
  /**
   * 书本id
   */
  bookId: number;
  /**
   * 借书时间
   */
  borrowDate?: string;
  /**
   * 是否续借
   */
  isRenew?: number;
  /**
   * 读者id
   */
  readerId: number;
  /**
   * 还书时间
   */
  returnDate?: string;
}

// 新增借书 接口
export interface newBorrow{
  bookId: number| undefined,
  borrowCardId?: number | undefined
  readerId?: number | undefined;
}

export interface borrowSelectInt {
  page: number; // 当前页
  count: number; // 记录总数
  pageSize: number; // 页数
  readerId: number;
}